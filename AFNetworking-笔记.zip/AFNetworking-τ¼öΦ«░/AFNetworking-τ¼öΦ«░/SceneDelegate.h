//
//  SceneDelegate.h
//  AFNetworking-笔记
//
//  Created by 徐金城 on 2020/9/9.
//  Copyright © 2020 xujincheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

