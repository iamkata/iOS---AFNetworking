//
//  AppDelegate.h
//  AFNetworking-笔记
//
//  Created by 徐金城 on 2020/9/9.
//  Copyright © 2020 xujincheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

